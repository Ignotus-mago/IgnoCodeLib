/**
Package <code>net.paulhertz.util</code> currently provides classes that support permutations of integer
arrays (such as lists of array indices) and various random number methods, including Gaussian distributions.
Other classes are in the works, as of version 0.1.1, the first release.
*/
package net.paulhertz.util;